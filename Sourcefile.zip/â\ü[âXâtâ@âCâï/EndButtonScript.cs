﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndButtonScript : MonoBehaviour
{
  
    public void EndButton() {

        //アプリケーションの終了
        Application.Quit();

    }
}
